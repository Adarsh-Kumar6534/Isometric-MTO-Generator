# Isometric Drawing to Automated MTO Generator

This is my submission for the Full-Stack AI Engineering Assessment. I built a system that takes piping isometric drawings (PDF, JPG, or PNG) and uses the Gemini AI Vision model to automatically trace the pipeline and extract a Material Take-Off (MTO) table.

## Setup Instructions (Reproducibility)

I made sure this is very easy to run. You have two options:

**Option 1: Docker (Recommended)**
1. Copy `backend/.env.example` to `backend/.env` and paste your Gemini API Key. (If you don't provide a key, my app uses a Graceful Degradation mock pipeline, so it still works!).
2. In the root folder, run: `docker-compose up --build`
3. Open `http://localhost:3000`

**Option 2: Manual Setup**
1. **Backend:** Navigate to `backend/`, run `pip install -r requirements.txt`, and start it with `uvicorn main:app --reload`.
2. **Frontend:** Navigate to `frontend/`, run `npm install`, and start it with `npm run dev`.

## Architecture Explanation

I built this with a modern, modular stack:
- **Frontend (Next.js & React):** Provides a clean, responsive UI with glassmorphism design. I used vanilla CSS to keep things lightweight. It handles file uploads and async polling so the UI never freezes.
- **Backend (FastAPI):** Handles the API routes (`/api/upload`, `/api/status`, `/api/mto`). I used FastAPI's `BackgroundTasks` to process the drawings asynchronously so we don't hold the HTTP request open for 60 seconds and cause timeouts.
- **Data Layer (Pydantic):** I strictly defined the MTO schema in `models.py` to ensure the AI output is always validated before it goes to the frontend.
- **AI Integration (Gemini 2.5 Flash):** I used Google's Generative AI to process the image. If you upload a PDF, I use `PyMuPDF` to transparently convert the first page to an image before sending it to Gemini.

## Assumptions & Limitations

I want to be honest about the limitations of this system:
1. **Zero-Shot LLM Limitations:** Getting perfect xy-coordinates for bounding boxes out of a zero-shot LLM prompt on dense CAD drawings is very unreliable. Instead of building a buggy bounding box overlay, I implemented a **Full-Screen Image Zoom** modal in the UI to give a better user experience for inspecting the drawing.
2. **Scale & Calibration:** The AI does a great job reading labeled dimensions, but it struggles to accurately calculate lengths of unlabeled straight pipe runs because isometric drawings are often not perfectly to scale. I added an instruction for it to assume standard lengths when missing.
3. **Single Page Restriction:** The current `PyMuPDF` implementation only extracts the first page of a PDF. Multi-sheet drawings would require a batch processing queue.

## Features & Bonus Points Completed
- **Graceful Fallback:** If you remove the API key, the app intercepts the error and returns a highly detailed 16-item mock MTO so the app never crashes.
- **Excel & CSV Export:** You can export the validated MTO to a perfectly formatted `.xlsx` file or a `.csv` file.
- **Docker Compose:** Fully containerized for 1-click running.
- **Weld Counting:** The AI prompt is configured to actively search for and count Field Welds. 

Hope you like the project!
